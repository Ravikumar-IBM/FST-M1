package Activities;
import io.restassured.RestAssured;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.builder.RequestSpecBuilder;;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Rest_Project {

    RequestSpecification requestSpec;
    String sshKey="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPY3+t2oqdTltW4Ts/vKRxqLtO6MmMSDYyTqMVMLpYAO";
    int id;
    String pat = "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";
    ResponseSpecification responseSpec;

    @BeforeClass
    public void setUp() {
        requestSpec = new RequestSpecBuilder()
                .setContentType(ContentType.JSON)
                .setBaseUri("https://api.github.com")
                //.addHeader("Authorization", "token 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")
                //.addHeader("Content-Type","application/json")
                .build();
    }

    @Test(priority = 1)
    public void testAddSSHKey(){
        String body="{\"title\": \"TestAPIKey\",\"key\": \""+sshKey+"\"}";
        System.out.println("body : "+body);
        Response response =
                RestAssured.given().spec(requestSpec)
                        .auth()
                        .oauth2(pat)// Use requestSpec
                        .body(body)
                        .post("/user/keys"); // Send GET request

        String resBody = response.getBody().asPrettyString();
        System.out.println(resBody);

        // Assertion
        Assert.assertEquals(response.getStatusCode(),201);
        id=response.jsonPath().getInt("id");
        System.out.println("id : "+id);
    }

    @Test(priority = 2)
    public void testGetKeyDetails() {
        Response response =
                RestAssured.given().spec(requestSpec) // Use requestSpec
                        .auth()
                        .oauth2(pat)// Use requestSpec
                        .pathParam("keyId", id) // Set path parameter
                        .get("/user/keys/{keyId}"); // Send GET request

        String body = response.getBody().asPrettyString();
        System.out.println(body);

        // Assertion
        Assert.assertEquals(response.getStatusCode(),200);
    }

    @Test(priority = 3)
    public void testDeleteSSHKey() {
        Response response =
                RestAssured.given().spec(requestSpec) // Use requestSpec
                        .auth()
                        .oauth2(pat)// Use requestSpec
                        .pathParam("keyId", id) // Set path parameter
                        .delete("/user/keys/{keyId}"); // Send Delete request

        String body = response.getBody().asPrettyString();
        System.out.println(body);

        // Assertion
        Assert.assertEquals(response.getStatusCode(),204);
    }


}